---
date: '3'
title: 'Yonia (iOS, Android)'
cover: './yonia.png'
github: 'https://github.com/poudelsakar1/Yonia'
tech:
  - React Native
  - Redux
  - Node.js
  - ES6
showInProjects: true
---

A feature rich react native recipe app template for food lovers, chefs and cooking experts.
Yonia app template makes it easier than ever to create and manage your own recipes through the easy to use powerful admin page.
<br/>
<a href="https://play.google.com/store/apps/details?id=react.native.recipes.template.yonia" target="_blank">Open Google Play </a><br/>
