---
date: '3'
title: 'AutoEz'
cover: './AutoEz.png'
github: 'https://github.com/poudelsakar1/Classifieds'
external: 'https://autoez.com/'
tech:
  - React.js
  - Hooks
  - Node.js
  - MongoDB Atlas
showInProjects: true
---

<a href="https://autoez.com">AutoEZ</a> is car dealing website. AutoEz allow all customers can choose best car according to their price and interest.
I developed this project as front-end developer using React(Functional Components, Context API, Hooks).
