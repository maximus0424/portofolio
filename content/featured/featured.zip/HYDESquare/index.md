---
date: '3'
title: 'HYDE SQUARE'
cover: './Hydesquare.png'
external: 'https://hydesquare.com'
tech:
  - Ruby on Rails
  - PostgreSQL
  - JavaScript
  - HTML5
showInProjects: true
---

<a href="https://hydesquare.com">The Platform</a> is luxury apartments for rent in Bellevue, WA | Hyde Square.
Users can see their best apartment for their price and can order in this website.
I developed this website using ruby on rails.
